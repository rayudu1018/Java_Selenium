package Java;

public class Averageofnumbers {
	
	

}
