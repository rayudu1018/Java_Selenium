package Java;

public class CountAllWords {

}
