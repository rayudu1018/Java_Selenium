package Java;

import java.util.Scanner;

public class Smallestnumber {
	
	public void methodsmallest() {
        
	Scanner Scan = new Scanner(System.in);
	
	int num1 = Scan.nextInt();
	int num2 = Scan.nextInt();
	int num3 = Scan.nextInt();

	System.out.println(" enter the 1st number");
  }
}

