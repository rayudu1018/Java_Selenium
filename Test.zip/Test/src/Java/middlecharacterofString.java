package Java;

public class middlecharacterofString {

}
