package Java;

public class VowelsCount {

}
