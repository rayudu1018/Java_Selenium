package Java;

public class MainMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SumOfTheDigits class1 = new SumOfTheDigits();
		
		class1.sumofnumbers();
		
		

	}

}
